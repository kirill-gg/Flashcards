package com.example.flashcards

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                val s = vm.screen
                BackHandler(enabled = s !is Screen.Decks) {
                    vm.screen = when (s) {
                        is Screen.Study -> Screen.DeckDetail(s.id, s.name)
                        else -> Screen.Decks
                    }
                }
                when (s) {
                    is Screen.Decks -> DeckListScreen(vm)
                    is Screen.DeckDetail -> DeckDetailScreen(vm, s)
                    is Screen.Study -> StudyScreen(vm, s)
                }
            }
        }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun InputDialog(
    title: String,
    labels: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (List<String>) -> Unit
) {
    val values = remember { mutableStateListOf(*Array(labels.size) { "" }) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                labels.forEachIndexed { i, l ->
                    OutlinedTextField(
                        value = values[i], onValueChange = { values[i] = it },
                        label = { Text(l) }, modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(values.toList()) }, enabled = values.all { it.isNotBlank() }) {
                Text("Добавить")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeckListScreen(vm: MainViewModel) {
    val decks by vm.decks.collectAsState()
    var adding by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.refresh() }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Колоды") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Default.Add, "Новая колода") }
        }
    ) { pad ->
        if (decks.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), Alignment.Center) {
                Text(
                    "Создайте первую колоду кнопкой +",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                Modifier.padding(pad),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(decks, key = { it.id }) { d ->
                    ElevatedCard(
                        Modifier.fillMaxWidth().clickable { vm.screen = Screen.DeckDetail(d.id, d.name) }
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(d.name, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Карточек: ${d.total}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (d.due > 0) Badge(containerColor = MaterialTheme.colorScheme.primary) {
                                Text("${d.due}", Modifier.padding(horizontal = 4.dp))
                            }
                        }
                    }
                }
            }
        }
    }
    if (adding) InputDialog("Новая колода", listOf("Название"), { adding = false }) {
        vm.addDeck(it[0]); adding = false
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeckDetailScreen(vm: MainViewModel, s: Screen.DeckDetail) {
    val cards by vm.cards(s.id).collectAsState(emptyList())
    val due = cards.count { it.due <= System.currentTimeMillis() }
    var adding by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(s.name) },
                navigationIcon = {
                    IconButton({ vm.screen = Screen.Decks }) { Icon(Icons.Default.ArrowBack, "Назад") }
                },
                actions = {
                    IconButton({ confirmDelete = true }) { Icon(Icons.Default.Delete, "Удалить колоду") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Default.Add, "Новая карточка") }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Button(
                onClick = { vm.screen = Screen.Study(s.id, s.name) },
                enabled = due > 0,
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) { Text(if (due > 0) "Учить ($due)" else "Нет карточек к повторению") }

            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cards, key = { it.id }) { c ->
                    OutlinedCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
                                Text(c.question, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    c.answer, style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton({ vm.deleteCard(c) }) { Icon(Icons.Default.Close, "Удалить") }
                        }
                    }
                }
            }
        }
    }
    if (adding) InputDialog("Новая карточка", listOf("Вопрос", "Ответ"), { adding = false }) {
        vm.addCard(s.id, it[0], it[1]); adding = false
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Удалить колоду?") },
        text = { Text("Все карточки колоды будут удалены.") },
        confirmButton = {
            TextButton({ vm.deleteDeck(s.id); confirmDelete = false; vm.screen = Screen.Decks }) { Text("Удалить") }
        },
        dismissButton = { TextButton({ confirmDelete = false }) { Text("Отмена") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyScreen(vm: MainViewModel, s: Screen.Study) {
    LaunchedEffect(s.id) { vm.startStudy(s.id) }
    val card = vm.queue.firstOrNull()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(s.name) },
                navigationIcon = {
                    IconButton({ vm.screen = Screen.DeckDetail(s.id, s.name) }) {
                        Icon(Icons.Default.ArrowBack, "Назад")
                    }
                },
                actions = { if (vm.loaded) Text("Осталось: ${vm.queue.size}  ", style = MaterialTheme.typography.labelLarge) }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
            if (!vm.loaded) return@Column
            if (card == null) {
                Column(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Готово! 🎉", style = MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Повторено карточек: ${vm.done}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Button(
                    { vm.screen = Screen.DeckDetail(s.id, s.name) },
                    Modifier.fillMaxWidth()
                ) { Text("К колоде") }
                return@Column
            }

            ElevatedCard(Modifier.weight(1f).fillMaxWidth()) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(card.question, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
                    if (vm.showAnswer) {
                        HorizontalDivider(Modifier.padding(vertical = 24.dp))
                        Text(card.answer, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))

            if (!vm.showAnswer) {
                Button({ vm.showAnswer = true }, Modifier.fillMaxWidth().height(56.dp)) { Text("Показать ответ") }
            } else {
                val cs = MaterialTheme.colorScheme
                val colors = mapOf(
                    Rating.AGAIN to (cs.errorContainer to cs.onErrorContainer),
                    Rating.HARD to (cs.secondaryContainer to cs.onSecondaryContainer),
                    Rating.GOOD to (cs.primaryContainer to cs.onPrimaryContainer),
                    Rating.EASY to (cs.tertiaryContainer to cs.onTertiaryContainer)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Rating.entries.forEach { r ->
                        val (bg, fg) = colors.getValue(r)
                        FilledTonalButton(
                            onClick = { vm.answer(r) },
                            modifier = Modifier.weight(1f).height(64.dp),
                            contentPadding = PaddingValues(2.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = bg, contentColor = fg)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(r.label, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                                Text(Scheduler.preview(card, r), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
