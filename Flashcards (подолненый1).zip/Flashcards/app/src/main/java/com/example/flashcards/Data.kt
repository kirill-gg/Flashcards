package com.example.flashcards

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "decks")
data class Deck(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(
    tableName = "cards",
    foreignKeys = [ForeignKey(Deck::class, ["id"], ["deckId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("deckId")]
)
data class Card(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deckId: Long,
    val question: String,
    val answer: String,
    val ease: Double = 2.5,   // коэффициент лёгкости SM-2
    val interval: Int = 0,    // текущий интервал в днях
    val reps: Int = 0,        // число успешных повторений подряд
    val due: Long = 0         // когда показать (мс); 0 = новая, сразу доступна
)

data class DeckInfo(val id: Long, val name: String, val total: Int, val due: Int)

@Dao
interface CardDao {
    @Query(
        """SELECT d.id, d.name,
           (SELECT COUNT(*) FROM cards c WHERE c.deckId = d.id) AS total,
           (SELECT COUNT(*) FROM cards c WHERE c.deckId = d.id AND c.due <= :now) AS due
           FROM decks d ORDER BY d.name COLLATE NOCASE"""
    )
    fun decksInfo(now: Long): Flow<List<DeckInfo>>

    @Insert suspend fun insertDeck(deck: Deck): Long
    @Query("DELETE FROM decks WHERE id = :id") suspend fun deleteDeck(id: Long)

    @Query("SELECT * FROM cards WHERE deckId = :deckId ORDER BY id DESC")
    fun cards(deckId: Long): Flow<List<Card>>

    @Query("SELECT * FROM cards WHERE deckId = :deckId AND due <= :now ORDER BY due, id")
    suspend fun dueCards(deckId: Long, now: Long): List<Card>

    @Insert suspend fun insertCard(card: Card)
    @Update suspend fun updateCard(card: Card)
    @Delete suspend fun deleteCard(card: Card)
}

@Database(entities = [Deck::class, Card::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): CardDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "flashcards.db")
                .build().also { instance = it }
        }
    }
}
