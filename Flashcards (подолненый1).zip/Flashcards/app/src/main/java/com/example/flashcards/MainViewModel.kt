package com.example.flashcards

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface Screen {
    data object Decks : Screen
    data class DeckDetail(val id: Long, val name: String) : Screen
    data class Study(val id: Long, val name: String) : Screen
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val now = MutableStateFlow(System.currentTimeMillis())

    var screen by mutableStateOf<Screen>(Screen.Decks)

    @OptIn(ExperimentalCoroutinesApi::class)
    val decks = now.flatMapLatest { dao.decksInfo(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun refresh() { now.value = System.currentTimeMillis() }
    fun addDeck(name: String) = viewModelScope.launch { dao.insertDeck(Deck(name = name.trim())) }
    fun deleteDeck(id: Long) = viewModelScope.launch { dao.deleteDeck(id) }
    fun cards(deckId: Long) = dao.cards(deckId)
    fun addCard(deckId: Long, q: String, a: String) =
        viewModelScope.launch { dao.insertCard(Card(deckId = deckId, question = q.trim(), answer = a.trim())) }
    fun deleteCard(c: Card) = viewModelScope.launch { dao.deleteCard(c) }

    // ---- Режим тренировки ----
    var queue by mutableStateOf<List<Card>>(emptyList()); private set
    var showAnswer by mutableStateOf(false)
    var loaded by mutableStateOf(false); private set
    var done by mutableIntStateOf(0); private set

    fun startStudy(deckId: Long) = viewModelScope.launch {
        loaded = false
        queue = dao.dueCards(deckId, System.currentTimeMillis())
        showAnswer = false
        done = 0
        loaded = true
    }

    fun answer(rating: Rating) {
        val card = queue.firstOrNull() ?: return
        val updated = Scheduler.next(card, rating)
        viewModelScope.launch { dao.updateCard(updated) }
        // «Снова» — карточка возвращается в конец текущей сессии
        queue = queue.drop(1) + if (rating == Rating.AGAIN) listOf(updated) else emptyList()
        if (rating != Rating.AGAIN) done++
        showAnswer = false
    }
}
