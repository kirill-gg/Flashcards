package com.example.flashcards

import kotlin.math.max
import kotlin.math.roundToInt

enum class Rating(val label: String) { AGAIN("Снова"), HARD("Трудно"), GOOD("Хорошо"), EASY("Легко") }

/** Упрощённый SM-2. */
object Scheduler {
    private const val DAY = 86_400_000L
    private const val MIN_EASE = 1.3

    fun next(c: Card, rating: Rating, now: Long = System.currentTimeMillis()): Card {
        if (rating == Rating.AGAIN) {
            // ошибка: серия обнуляется, карточка вернётся через минуту
            return c.copy(ease = max(MIN_EASE, c.ease - 0.2), reps = 0, interval = 0, due = now + 60_000)
        }
        var ease = c.ease
        val interval = when (rating) {
            Rating.HARD -> {
                ease = max(MIN_EASE, ease - 0.15)
                if (c.interval == 0) 1 else max(c.interval + 1, (c.interval * 1.2).roundToInt())
            }
            Rating.GOOD -> when (c.reps) {
                0 -> 1
                1 -> 6
                else -> max(c.interval + 1, (c.interval * ease).roundToInt())
            }
            else -> { // EASY
                ease += 0.15
                when (c.reps) {
                    0 -> 4
                    1 -> 8
                    else -> max(c.interval + 2, (c.interval * ease * 1.3).roundToInt())
                }
            }
        }
        return c.copy(ease = ease, reps = c.reps + 1, interval = interval, due = now + interval * DAY)
    }

    /** Подпись интервала для кнопки. */
    fun preview(c: Card, rating: Rating): String {
        val d = next(c, rating).interval
        return when {
            d == 0 -> "<1 мин"
            d < 30 -> "$d дн"
            d < 365 -> "${(d / 30.0).roundToInt()} мес"
            else -> "%.1f г".format(d / 365.0)
        }
    }
}
